CREATE VIEW ticketsV AS SELECT t.id,
       mc.management_company,
       mc.manager_name,
       md.micro_district,
       t.address,
       t.flat,
       t.floor,
       t.floors_number,
       hm.house_material,
       st.name as `status_name`,
       rt.riser_type,
       t.riser_count,
       rof.roofing_type,
       t.creation_date,
       t.last_status_set_date,
       t.installer,
       t.flexible_field_1,
       t.flexible_field_2,
       t.flexible_field_3,
       t.flexible_field_4,
       t.flexible_field_5,
       t.debt,
       t.management_company as 'management_company_id',
       t.micro_district as 'micro_district_id',
       t.house_material_id,
       t.status_id,
       t.riser_type_id,
       t.roofing_type_id,
       t.phone1,
       t.phone2,
       t.phone3
  FROM tickets t
       LEFT JOIN
       house_materials hm ON hm.id = t.house_material_id
       LEFT JOIN
       management_companies mc ON mc.id = t.management_company
       LEFT JOIN
       micro_districts md ON md.id = t.micro_district
       LEFT JOIN
       riser_types rt ON rt.id = t.riser_type_id
       LEFT JOIN
       roofing_types rof ON rof.id = t.roofing_type_id
       LEFT JOIN
       statuses st ON st.id = t.status_id